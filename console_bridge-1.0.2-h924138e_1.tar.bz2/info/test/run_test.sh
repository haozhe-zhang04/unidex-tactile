

set -ex



pkg-config --modversion console_bridge
pkg-config --exists --print-errors --debug console_bridge
pkg-config --validate --print-errors --debug console_bridge
test -f $PREFIX/lib/libconsole_bridge$SHLIB_EXT
exit 0
